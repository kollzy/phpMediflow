-- MariaDB dump 10.19  Distrib 10.4.28-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: mediflow
-- ------------------------------------------------------
-- Server version	10.4.28-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `appointment`
--

DROP TABLE IF EXISTS `appointment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointment` (
  `AppointmentId` int(3) NOT NULL,
  `MRN` int(3) DEFAULT NULL,
  `ArrivalDate` date NOT NULL,
  `ArrivalTime` time NOT NULL,
  `Fees` decimal(7,2) DEFAULT NULL,
  `ArrivalStatus` varchar(15) DEFAULT 'NA',
  `PaymentStatus` varchar(25) DEFAULT 'UNPAID',
  `MDN` int(3) DEFAULT NULL,
  PRIMARY KEY (`AppointmentId`),
  KEY `MRN` (`MRN`),
  KEY `FK_MDN` (`MDN`),
  CONSTRAINT `FK_MDN` FOREIGN KEY (`MDN`) REFERENCES `doctors` (`MDN`),
  CONSTRAINT `appointment_ibfk_2` FOREIGN KEY (`MRN`) REFERENCES `patients` (`MRN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appointment`
--

LOCK TABLES `appointment` WRITE;
/*!40000 ALTER TABLE `appointment` DISABLE KEYS */;
INSERT INTO `appointment` VALUES (752,236,'2024-04-29','09:00:00',NULL,'NA','UNPAID',678),(888,236,'2024-04-28','01:00:00',80.00,'arrived','COVERE',678);
/*!40000 ALTER TABLE `appointment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `doctors`
--

DROP TABLE IF EXISTS `doctors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctors` (
  `MDN` int(3) NOT NULL,
  `name` char(30) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `phone` varchar(15) NOT NULL,
  PRIMARY KEY (`MDN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctors`
--

LOCK TABLES `doctors` WRITE;
/*!40000 ALTER TABLE `doctors` DISABLE KEYS */;
INSERT INTO `doctors` VALUES (234,'Jane Doe','janedoe@example.com','9876543210'),(345,'Robert Johnson','robertjohnson@example.com','5551234567'),(456,'Emily Davis','emilydavis@example.com','1112223333'),(567,'Michael Brown','michaelbrown@example.com','9998887777'),(652,'Julius Kehinde','Kolakehinde485@gmail.com','0871036095'),(678,'Sophia Wilson','sophiawilson@example.com','4445556666');
/*!40000 ALTER TABLE `doctors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `patients`
--

DROP TABLE IF EXISTS `patients`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patients` (
  `MRN` int(3) NOT NULL,
  `Name` varchar(40) NOT NULL,
  `Email` varchar(50) DEFAULT NULL,
  `HomeAddress` varchar(80) NOT NULL,
  `Phone` varchar(15) NOT NULL,
  `MedicalCard` varchar(3) DEFAULT 'NO',
  PRIMARY KEY (`MRN`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `patients`
--

LOCK TABLES `patients` WRITE;
/*!40000 ALTER TABLE `patients` DISABLE KEYS */;
INSERT INTO `patients` VALUES (236,'Sam Noah','SamNoah23@gmail.com','tralee town center appartment','0861927854','yes'),(532,'Jane Sarah','janeSarah@gmail.com','Cork, Ireland','9876543210','no'),(799,'James Robert','robertjames6@gmail.com','Galway, Ireland','5551234567','yes');
/*!40000 ALTER TABLE `patients` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-04-28 14:21:41
